package dataportal.generator;

import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import lombok.extern.slf4j.Slf4j;
import com.gitee.kamismile.stoneComEx.common.component.server.SimpleFluxController;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Slf4j
public class CodeGenerator {
    /**
     * <p>
     * 读取控制台内容
     * </p>
     */
    public static String scanner(String tip) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder help = new StringBuilder();
        help.append("请输入" + tip + "：");
        System.out.println(help.toString());
        if (scanner.hasNext()) {
            String ipt = scanner.next();
            if (StringUtils.isNotEmpty(ipt)) {
                return ipt;
            }
        }
        throw new MybatisPlusException("请输入正确的" + tip + "！");
    }


    public static String dbDriver = "com.mysql.cj.jdbc.Driver";
    public static String[] tables = {
            "qmyz_alipay_log"
    };

    public static String codePackage = "com.max";
    public static String codeModule = "system";
    public static AutoGenerator autoGenerator = new AutoGenerator();

    public static String projectPath = "";

    public static void main(String[] args) {
        //设置数据库
        // 代码生成器
        // set freemarker engine
        autoGenerator.setTemplateEngine(new FreemarkerTemplateEngine());
        projectPath = System.getProperty("user.dir");

        // 数据源配置
        DataSourceConfig dataSource = getDataSourceConfig();
        autoGenerator.setDataSource(dataSource);

        // 策略配置
        StrategyConfig strategy = getStrategyConfig();
        autoGenerator.setStrategy(strategy);


        // 配置模板
        createApi();
//        createFacade();
//        createWeb();

    }

    private static void createWeb() {
        // 包配置
        PackageConfig packageConfig = getPackageConfig();
        autoGenerator.setPackageInfo(packageConfig);

        TemplateConfig templateConfig = getWebTemplateConfig();
        autoGenerator.setTemplate(templateConfig);
        autoGenerator.execute();
    }

    private static TemplateConfig getWebTemplateConfig() {
        autoGenerator.setConfig(null);
        // 全局配置
        GlobalConfig globalConfig = getGlobalConfig(projectPath + "/" + "manager");
        autoGenerator.setGlobalConfig(globalConfig);

        TemplateConfig templateConfig = new TemplateConfig();
        templateConfig.setController("/ftl/controller.java");
//        templateConfig.setIntegration("/ftl/integration.java");
        templateConfig.setIntegration(null);
        templateConfig.setService(null);
        templateConfig.setServiceImpl(null);
        templateConfig.setEntity(null);
        templateConfig.setMapper(null);
        templateConfig.setMapperDto(null);
        templateConfig.setReqDto(null);
        templateConfig.setResponseDto(null);
        templateConfig.setFacade(null);
        templateConfig.setFacadeImpl(null);
        // 配置自定义输出模板
        //指定自定义模板路径，注意不要带上.ftl/.vm, 会根据使用的模板引擎自动识别
        // templateConfig.setEntity("templates/entity2.java");
        // templateConfig.setService();
        // templateConfig.setController();

        templateConfig.setXml(null);
        return templateConfig;
    }

    private static void createFacade() {
        // 包配置
        PackageConfig packageConfig = getPackageConfig("facade");
        autoGenerator.setPackageInfo(packageConfig);


        TemplateConfig templateConfig = getFacadeTemplateConfig();
        autoGenerator.setTemplate(templateConfig);
        autoGenerator.execute();
    }

    private static void createApi() {
        // 包配置
        PackageConfig packageConfig = getPackageConfig();
        autoGenerator.setPackageInfo(packageConfig);
        // 自定义配置
        InjectionConfig cfg = getInjectionConfig();
        autoGenerator.setCfg(cfg);

        TemplateConfig templateConfig = getApiTemplateConfig();
        autoGenerator.setTemplate(templateConfig);
        autoGenerator.execute();
    }

    private static StrategyConfig getStrategyConfig() {
        StrategyConfig strategy = new StrategyConfig();
        strategy.setNaming(NamingStrategy.underline_to_camel);
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);
        //strategy.setSuperEntityClass("com.baomidou.ant.common.BaseEntity");
        strategy.setEntityLombokModel(false);
        strategy.setRestControllerStyle(true);
        strategy.setSuperControllerClass(SimpleFluxController.class.getName());
        strategy.setInclude(tables);
//        strategy.setSuperEntityColumns("id");
        //strategy.setControllerMappingHyphenStyle(true);
        return strategy;
    }

    private static TemplateConfig getFacadeTemplateConfig() {
        autoGenerator.setConfig(null);
        // 全局配置
        GlobalConfig globalConfig = getGlobalConfig(projectPath + "/" + "facade");
        autoGenerator.setGlobalConfig(globalConfig);

        TemplateConfig templateConfig = new TemplateConfig();
//        templateConfig.setController("/ftl/controller.java");
//        templateConfig.setEntity("/ftl/entity.java");
//        templateConfig.setMapper("/ftl/mapper.java");
//        templateConfig.setService("/ftl/service.java");
//        templateConfig.setServiceImpl("/ftl/serviceImpl.java");
//        templateConfig.setDto("/ftl/dto.java");
        templateConfig.setReqDto("/ftl/reqDto.java");
        templateConfig.setResponseDto("/ftl/responseDto.java");
        templateConfig.setFacade("/ftl/facade.java");
        templateConfig.setIntegration(null);
        templateConfig.setMapperDto(null);
        templateConfig.setIntegration(null);
        templateConfig.setFacadeImpl(null);
        templateConfig.setController(null);
        templateConfig.setEntity(null);
        templateConfig.setMapper(null);
        templateConfig.setService(null);
        templateConfig.setServiceImpl(null);
        // 配置自定义输出模板
        //指定自定义模板路径，注意不要带上.ftl/.vm, 会根据使用的模板引擎自动识别
        // templateConfig.setEntity("templates/entity2.java");
        // templateConfig.setService();
        // templateConfig.setController();

        templateConfig.setXml(null);
        return templateConfig;
    }

    private static TemplateConfig getApiTemplateConfig() {
        autoGenerator.setConfig(null);
        // 全局配置
        GlobalConfig globalConfig = getGlobalConfig(projectPath + "/" + codeModule + "Api");
        autoGenerator.setGlobalConfig(globalConfig);

        TemplateConfig templateConfig = new TemplateConfig();
        templateConfig.setMapperDto("/ftl/mapperDto.java");
        templateConfig.setEntity("/ftl/entity.java");
        templateConfig.setMapper("/ftl/mapper.java");
        templateConfig.setService("/ftl/service.java");
        templateConfig.setServiceImpl("/ftl/serviceImpl.java");
        templateConfig.setFacadeImpl("/ftl/facadeImpl.java");
        templateConfig.setFacade(null);
        templateConfig.setIntegration(null);
        templateConfig.setController(null);
        templateConfig.setReqDto(null);
        templateConfig.setResponseDto(null);
        templateConfig.setXml(null);
        return templateConfig;
    }

    private static InjectionConfig getInjectionConfig() {
        InjectionConfig cfg = new InjectionConfig() {
            @Override
            public void initMap() {
                // to do nothing
            }
        };

        // 如果模板引擎是 freemarker
        String templatePath = "/ftl/mapper.xml.ftl";
        // 如果模板引擎是 velocity
        // String templatePath = "/templates/mapper.xml.vm";

        // 自定义输出配置
        List<FileOutConfig> focList = new ArrayList<>();
        // 自定义配置会被优先输出
        focList.add(new FileOutConfig(templatePath) {
            @Override
            public String outputFile(TableInfo tableInfo) {
                // 自定义输出文件名 ， 如果你 Entity 设置了前后缀、此处注意 xml 的名称会跟着发生变化！！
                return projectPath + "/" + codeModule + "Api" + "/src/main/java/" + codePackage.replaceAll("\\.", "/") + "/" + codeModule + "/mapper/" + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;
            }
        });

        cfg.setFileOutConfigList(focList);
        return cfg;
    }

    private static PackageConfig getPackageConfig(String suffix) {
        PackageConfig packageConfig = new PackageConfig();
        if (StringUtils.isNotEmpty(suffix)) {
            suffix = "." + suffix;
        }
        packageConfig.setParent(codePackage + suffix);
        packageConfig.setModuleName(codeModule);
        return packageConfig;
    }

    private static PackageConfig getPackageConfig() {
        return getPackageConfig("");
    }

    private static GlobalConfig getGlobalConfig(String suffix) {
        GlobalConfig globalConfig = new GlobalConfig();
        globalConfig.setOutputDir(suffix + "/src/main/java");
        globalConfig.setAuthor("yeats");
        globalConfig.setOpen(false);
        globalConfig.setFileOverride(true);
        globalConfig.setSwagger2(true);
        globalConfig.setBaseResultMap(true);
        globalConfig.setBaseColumnList(true);
        //globalConfig.setDateType(true);
        globalConfig.setServiceName("%sService");
        // gc.setSwagger2(true); 实体属性 Swagger2 注解
        return globalConfig;
    }

    private static DataSourceConfig getDataSourceConfig() {
        DataSourceConfig dataSource = new DataSourceConfig();

        return dataSource;
    }
}
