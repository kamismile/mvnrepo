/*
 * Copyright (c) 2011-2020, baomidou (jobob@qq.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.baomidou.mybatisplus.generator.config;

import com.baomidou.mybatisplus.core.toolkit.StringPool;

import java.nio.charset.StandardCharsets;

/**
 * 定义常量
 *
 * @author YangHu, tangguo, hubin
 * @since 2016-08-31
 */
public interface ConstVal {

    String MODULE_NAME = "ModuleName";

    String ENTITY = "Entity";
    String MAPPERDTO = "MapperDto";
    String REQDTO = "ReqDto";
    String RESPONSEDTO = "ResponseDto";
    String SERVICE = "Service";
    String SERVICE_IMPL = "ServiceImpl";
    String MAPPER = "Mapper";
    String XML = "Xml";
    String CONTROLLER = "Controller";
    String FACADE = "Facade";
    String FACADE_IMPL = "FacadeImpl";
    String INTEGRATION = "integration";

    String ENTITY_PATH = "entity_path";
    String MAPPER_DTO_PATH = "mapper_dto_path";
    String REQ_DTO_PATH = "req_dto_path";
    String RESPONSE_DTO_PATH = "response_dto_path";
    String SERVICE_PATH = "service_path";
    String SERVICE_IMPL_PATH = "service_impl_path";
    String FACADE_PATH = "facade_path";
    String FACADE_IMPL_PATH = "facade_impl_path";
    String MAPPER_PATH = "mapper_path";
    String XML_PATH = "xml_path";
    String CONTROLLER_PATH = "controller_path";
    String INTEGRATION_PATH = "integration_path";


    String JAVA_TMPDIR = "java.io.tmpdir";
    String UTF8 = StandardCharsets.UTF_8.name();
    String UNDERLINE = "_";

    String JAVA_SUFFIX = StringPool.DOT_JAVA;
    String KT_SUFFIX = ".kt";
    String XML_SUFFIX = ".xml";

    String TEMPLATE_ENTITY_JAVA = "/ftl/entity.java";
    String TEMPLATE_ENTITY_KT = "/templates/entity.kt";
    String TEMPLATE_MAPPER = "/ftl/mapper.java";
    String TEMPLATE_XML = "/ftl/mapper.xml";
    String TEMPLATE_SERVICE = "/ftl/service.java";
    String TEMPLATE_SERVICE_IMPL = "/ftl/serviceImpl.java";
    String TEMPLATE_FACADE = "/ftl/facade.java";
    String TEMPLATE_FACADE_IMPL = "/ftl/facadeImpl.java";
    String TEMPLATE_CONTROLLER = "/ftl/controller.java";
    String TEMPLATE_INTEGRATION = "/ftl/integration.java";
    String TEMPLATE_MAPPER_DTO = "/ftl/mapperDto.java";
    String TEMPLATE_REQ_DTO = "/ftl/reqDto.java";
    String TEMPLATE_RESPONSE_DTO = "/ftl/responseDto.java";

    String VM_LOAD_PATH_KEY = "file.resource.loader.class";
    String VM_LOAD_PATH_VALUE = "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader";

    String SUPER_MAPPER_CLASS = "com.baomidou.mybatisplus.core.mapper.BaseMapper";
    String SUPER_SERVICE_CLASS = "com.baomidou.mybatisplus.extension.service.IService";
    String SUPER_SERVICE_IMPL_CLASS = "com.baomidou.mybatisplus.extension.service.impl.ServiceImpl";
}
